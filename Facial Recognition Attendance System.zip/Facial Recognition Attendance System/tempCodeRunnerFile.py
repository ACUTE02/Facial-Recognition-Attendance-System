            # Optionally clear the entries after successful capture
